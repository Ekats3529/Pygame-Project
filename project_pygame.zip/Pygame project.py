import pygame
import os
from random import choice
pygame.init()

types_col = ['red', 'yellow', 'orange']
size = width, height = 1000, 630
screen = pygame.display.set_mode(size)


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
        image = image.convert_alpha()
        if colorkey is not None:
            if colorkey is -1:
                colorkey = image.get_at((0, 0))
            image.set_colorkey(colorkey)
        return image
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)


class Brick(pygame.sprite.Sprite):
    red = load_image("brick_red.png")
    orange = load_image("brick_org.png")
    yellow = load_image("brick_yel.png")

    def __init__(self, group, x, y, color):
        pygame.sprite.Sprite.__init__(self)
        super().__init__(group)
        if color == 'red':
            self.image = Brick.red
        elif color == 'orange':
            self.image = Brick.orange
        else:
            self.image = Brick.yellow
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.color = color

    def update(self):
        pass

    def get_event(self, event):
        pass


size = width, height = 1000, 630
screen = pygame.display.set_mode(size)
image = load_image("platform.png")
all_sprites = pygame.sprite.Group()
for i in range(10):
    if i % 2 == 0:
        for g in range(15):
            x = g * 41 + 200
            y = i * 25 + 100
            Brick(all_sprites, x, y, choice(types_col))
    else:
        for g in range(14):
            x = g * 41 + 220
            y = i * 25 + 100
            Brick(all_sprites, x, y, choice(types_col))

pygame.mouse.set_visible(False)
coords = pygame.mouse.get_pos()
x = coords[0]
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEMOTION:
            x = event.pos[0]
        if x > 820:
            x = 820
        coords = (x, 561)
        screen.blit(image, coords)
        all_sprites.draw(screen)
        pygame.display.flip()
        screen.fill((0, 0, 0))
pygame.quit()