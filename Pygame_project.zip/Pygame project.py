import pygame
import os
import sys
from random import choice
import random
pygame.init()

types_col = ['red', 'yellow', 'orange']
size = width, height = 1000, 630
screen = pygame.display.set_mode(size)
vx = 300
vy = -300


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
        image = image.convert_alpha()
        if colorkey is not None:
            if colorkey is -1:
                colorkey = image.get_at((0, 0))
            image.set_colorkey(colorkey)
        return image
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)


class Brick(pygame.sprite.Sprite):
    red = load_image("brick_red.png")
    orange = load_image("brick_org.png")
    yellow = load_image("brick_yel.png")
    orange_br = load_image("broken_brick_org.png")
    red_br_1 = load_image("broken_brick_red.png")
    red_br_2 = load_image("broken_brick_red_2.png")

    def __init__(self, x, y, color):
        pygame.sprite.Sprite.__init__(self)
        super().__init__(all_sprites)
        self.add(bricks)
        self.red = 0
        self.org = 0
        if color == 'red':
            self.color = 'red'
            self.image = Brick.red

        elif color == 'orange':
            self.color = 'orange'
            self.image = Brick.orange

        else:
            self.color = 'yel'
            self.image = Brick.yellow

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def update(self):
        if self.color == 'red' and self.red == 0:
            self.image = Brick.red_br_1
            self.red = 1
            return True
        elif self.color == 'red' and self.red == 1:
            self.image = Brick.red_br_2
            self.red = 2
            return True
        elif self.color == 'orange' and self.org == 0:
            self.image = Brick.orange_br
            self.org = 1
            return True
        else:
            return False


class Ball(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        super().__init__(all_sprites)
        self.image = pygame.Surface((2 * 15, 2 * 15),
                                    pygame.SRCALPHA, 32)
        pygame.draw.circle(screen, pygame.Color("white"),
                           (x, y), 15)
        self.rect = pygame.Rect(x - 15, y - 15, 2 * 15, 2 * 15)
        self.vx = 200
        self.vy = -200

    def update(self):
        global vx, vy
        if pygame.sprite.spritecollideany(self, bricks):
            vy = -vy
            if not pygame.sprite.spritecollideany(self, bricks).update():
                pygame.sprite.spritecollideany(self, bricks).kill()


size = width, height = 1000, 630
screen = pygame.display.set_mode(size)
image = load_image("platform.png")
all_sprites = pygame.sprite.Group()
bricks = pygame.sprite.Group()

for i in range(10):
    if i % 2 == 0:
        for g in range(15):
            x = g * 41 + 200
            y = i * 25 + 100
            Brick(x, y, choice(types_col))
    else:
        for g in range(14):
            x = g * 41 + 220
            y = i * 25 + 100
            Brick(x, y, choice(types_col))


def terminate():
    pygame.quit()
    sys.exit()


def start_screen():
    intro_text = ["          ПРАВИЛА",
                  "Нужно разбить все блоки на экране",
                  "шариком который отбивается от платформы",
                  "при этом он не должен улететь за пределы платформы.",
                  "",
                  "  Для начала игры нажмите 'пробел'"]

    fon = load_image('fon.jpg')
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 50)
    text_coord = 150
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('red'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)
    pygame.display.flip()


def game_over_screen():
    fon = load_image('Game_over.png')
    screen.blit(fon, (0, 0))
    pygame.display.flip()


def win_screen():
    fon = load_image('win.png')
    screen.blit(fon, (0, 0))
    pygame.display.flip()


coords = pygame.mouse.get_pos()
x = coords[0]
fps = 60
x_pos = 0
y_pos = 0
clock = pygame.time.Clock()
color = pygame.Color('blue')
centre = pygame.mouse.get_pos()
life = load_image("heart.png")
ball_sprite = pygame.sprite.Sprite()
running = False
f = False
life_count = 3
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            terminate()
        elif event.type == pygame.MOUSEMOTION:
            x = event.pos[0]
        elif event.type == pygame.MOUSEBUTTONDOWN and running:
            f = True
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            running = True
        if x > 820:
            x = 820
    if running:
        pygame.mouse.set_visible(False)
        if not f:
            coords = (x, 561)
            centre = (x + 15, 561 - 15)
        else:
            coords = (x, 561)
        screen.blit(image, coords)
        if life_count == 3:
            screen.blit(life, (850, 10))
            screen.blit(life, (900, 10))
            screen.blit(life, (950, 10))
        elif life_count == 2:
            screen.blit(life, (900, 10))
            screen.blit(life, (950, 10))
        elif life_count == 1:
            screen.blit(life, (950, 10))
        else:
            game_over_screen()
            break
        if f:
            x1 = centre[0] + int(x_pos)
            y1 = centre[-1] + int(y_pos)
            if x1 >= (width - 15):
                vx = -300
            elif x1 < 15:
                vx = 300
            if y1 >= (height - 15):
                vy = -300
            elif y1 < 15:
                vy = 300
            if coords[0] - 15 < x1 < coords[0] + 195 and y1 >= 563 - 15:
                vy = -300
            elif (not coords[0] - 15 < x1 < coords[0] + 195) and y1 > 563 - 15:
                life_count -= 1
                x_pos = 0
                y_pos = 0
                f = False
            Ball(x1, y1).update()
            if len(bricks.sprites()) == 0:
                win_screen()
                break
            x_pos += vx / fps
            y_pos += vy / fps
            clock.tick(fps)
        else:
            Ball(centre[0], centre[-1])
        all_sprites.draw(screen)
        clock.tick(fps)
        pygame.display.flip()
        screen.fill((0, 0, 0))
    else:
        start_screen()
